npm install
add DB_STRING to .env file