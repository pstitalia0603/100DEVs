---
name: Feature Request
about: Use this template for requesting new features
label: ["feature-request"]
---

# Summary
<!-- What is the feature? Is there a user story that this feature addresses? -->

# Additional notes
<!-- (Optional)
- suggest assignees
- suggest libraries, plan of action, etc.
-->